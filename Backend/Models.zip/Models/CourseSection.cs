﻿using System;
using System.Collections.Generic;

namespace Backend.Models
{
    // قسم داخل الكورس (Module / Chapter)
    public class CourseSection
    {
        public int Id { get; set; }

        // أي كورس يتبع؟
        public int CourseId { get; set; }
        public Course Course { get; set; }

        // عنوان القسم (مثلاً: Introduction, Basics, Advanced...)
        public string Title { get; set; }

        // ترتيب القسم داخل الكورس
        public int Order { get; set; }

        // عناصر المحتوى داخل هذا القسم (نضيفها في الخطوة القادمة)
        public List<CourseContentItem> ContentItems { get; set; } = new();
    }
}
