﻿using System.Collections.Generic;

namespace Backend.Models
{
    public class Course
    {
        public int Id { get; set; }

        public string Title { get; set; }       // اسم الكورس
        public string Description { get; set; } // وصف مختصر
        public decimal Price { get; set; }      // السعر
        public bool IsActive { get; set; } = true;

        // ربط بالكتب الخاصة بالكورس
        public ICollection<CourseBook> CourseBooks { get; set; }
    }
}
