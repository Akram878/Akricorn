﻿using System;

namespace Backend.Models
{
    public enum CourseContentType
    {
        Text = 0,
        Image = 1,
        Video = 2,
        File = 3
    }

    // عنصر محتوى داخل قسم داخل كورس
    public class CourseContentItem
    {
        public int Id { get; set; }

        // لأي Section يتبع؟
        public int CourseSectionId { get; set; }
        public CourseSection Section { get; set; }

        // نوع المحتوى
        public CourseContentType ContentType { get; set; }

        // عنوان صغير (اختياري)
        public string Title { get; set; }


        // نص (في حالة ContentType = Text)
        public string? Text { get; set; }

        // رابط صورة / فيديو / ملف
        public string? MediaUrl { get; set; }

        // ترتيب البلوك داخل القسم
        public int Order { get; set; }
    }
}
