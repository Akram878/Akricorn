﻿using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LmsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public LmsController(AppDbContext context)
        {
            _context = context;
        }

        // Helper: الحصول على Id المستخدم الحالي من الـ JWT
        private int? GetCurrentUserId()
        {
            var sub = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                      ?? User.FindFirst("sub")?.Value; // لأننا وضعنا Id في الـ "sub" بالـ JWT

            if (int.TryParse(sub, out var userId))
                return userId;

            return null;
        }

        // ============================
        //        Public: Courses
        // ============================

        // كل الكورسات المتاحة للشراء
        [HttpGet("courses")]
        [AllowAnonymous]
        public async Task<IActionResult> GetCourses()
        {
            var courses = await _context.Courses
                .Where(c => c.IsActive)
                .Select(c => new
                {
                    c.Id,
                    c.Title,
                    c.Description,
                    c.Price
                })
                .ToListAsync();

            return Ok(courses);
        }

        // كورسات المستخدم (My Courses)
        [HttpGet("my-courses")]
        [Authorize]
        public async Task<IActionResult> GetMyCourses()
        {
            var userId = GetCurrentUserId();
            if (userId == null)
                return Unauthorized();

            var myCourses = await _context.UserCourses
                .Where(uc => uc.UserId == userId.Value)
                .Include(uc => uc.Course)
                .Select(uc => new
                {
                    uc.Course.Id,
                    uc.Course.Title,
                    uc.Course.Description,
                    uc.Course.Price,
                    uc.PurchasedAt
                })
                .ToListAsync();

            return Ok(myCourses);
        }

        // شراء كورس (نربط الدفع لاحقاً)
        [HttpPost("courses/{courseId}/purchase")]
        [Authorize]
        public async Task<IActionResult> PurchaseCourse(int courseId)
        {
            var userId = GetCurrentUserId();
            if (userId == null)
                return Unauthorized();

            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .FirstOrDefaultAsync(c => c.Id == courseId && c.IsActive);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            // هل المستخدم يملك الكورس مسبقاً؟
            var alreadyOwned = await _context.UserCourses
                .AnyAsync(uc => uc.UserId == userId.Value && uc.CourseId == courseId);

            if (alreadyOwned)
            {
                return BadRequest(new { message = "You already own this course." });
            }

            // TODO لاحقاً: التحقق من الدفع / الرصيد قبل منح الكورس

            var userCourse = new UserCourse
            {
                UserId = userId.Value,
                CourseId = courseId,
                PurchasedAt = DateTime.UtcNow
            };

            _context.UserCourses.Add(userCourse);

            // منح الكتب الخاصة بهذا الكورس مجاناً
            if (course.CourseBooks != null && course.CourseBooks.Any())
            {
                foreach (var cb in course.CourseBooks)
                {
                    var alreadyHasBook = await _context.UserBooks
                        .AnyAsync(ub => ub.UserId == userId.Value && ub.BookId == cb.BookId);

                    if (!alreadyHasBook)
                    {
                        _context.UserBooks.Add(new UserBook
                        {
                            UserId = userId.Value,
                            BookId = cb.BookId,
                            GrantedAt = DateTime.UtcNow,
                            IsFromCourse = true
                        });
                    }
                }
            }

            await _context.SaveChangesAsync();

            return Ok(new { message = "Course purchased successfully." });
        }

        // ============================
        //        Public: Books
        // ============================

        // كل الكتب المتاحة (لـ Library)
        [HttpGet("books")]
        [AllowAnonymous]
        public async Task<IActionResult> GetBooks()
        {
            var books = await _context.Books
                .Where(b => b.IsActive)
                .Select(b => new
                {
                    b.Id,
                    b.Title,
                    b.Description,
                    b.Price,
                    b.FileUrl
                })
                .ToListAsync();

            return Ok(books);
        }

        // كتب المستخدم (من شراء مباشر أو من كورس)
        [HttpGet("my-books")]
        [Authorize]
        public async Task<IActionResult> GetMyBooks()
        {
            var userId = GetCurrentUserId();
            if (userId == null)
                return Unauthorized();

            var myBooks = await _context.UserBooks
                .Where(ub => ub.UserId == userId.Value)
                .Include(ub => ub.Book)
                .Select(ub => new
                {
                    ub.Book.Id,
                    ub.Book.Title,
                    ub.Book.Description,
                    ub.Book.Price,
                    ub.Book.FileUrl,
                    ub.IsFromCourse,
                    ub.GrantedAt
                })
                .ToListAsync();

            return Ok(myBooks);
        }
    }
}
