﻿using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Backend.Controllers
{
    public class UploadCourseContentFileRequest
    {
        public int SectionId { get; set; }
        public IFormFile File { get; set; } = default!;
    }

    [ApiController]
    [Route("api/admin/course-content")]
    [Authorize(Policy = "AdminOnly")]
    public class CourseContentAdminController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CourseContentAdminController(AppDbContext context)
        {
            _context = context;
        }

        // ===============================================
        //  Get full course content with sections & items
        // ===============================================
        [HttpGet("course/{courseId}")]
        public async Task<IActionResult> GetCourseContent(int courseId)
        {
            var course = await _context.Courses
                .Include(c => c.Sections)
                    .ThenInclude(s => s.ContentItems)
                .FirstOrDefaultAsync(c => c.Id == courseId);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            var response = new
            {
                course.Id,
                course.Title,
                course.Description,
                Sections = course.Sections
                    .OrderBy(s => s.Order)
                    .Select(s => new
                    {
                        s.Id,
                        s.Title,
                        s.Order,
                        Items = s.ContentItems
                            .OrderBy(ci => ci.Order)
                            .Select(ci => new
                            {
                                ci.Id,
                                ContentType = ci.ContentType.ToString(),
                                ci.Title,
                                ci.Text,
                                ci.MediaUrl,
                                ci.Order
                            })
                    })
            };

            return Ok(response);
        }

        // ===============================================
        //  Create Section
        // ===============================================
        public class CreateSectionRequest
        {
            public string Title { get; set; } = "";
        }

        [HttpPost("course/{courseId}/sections")]
        public async Task<IActionResult> CreateSection(int courseId, [FromBody] CreateSectionRequest request)
        {
            var course = await _context.Courses.FindAsync(courseId);
            if (course == null)
                return NotFound(new { message = "Course not found." });

            var maxOrder = await _context.CourseSections
                .Where(s => s.CourseId == courseId)
                .Select(s => (int?)s.Order)
                .MaxAsync() ?? 0;

            var section = new CourseSection
            {
                CourseId = courseId,
                Title = request.Title,
                Order = maxOrder + 1
            };

            _context.CourseSections.Add(section);
            await _context.SaveChangesAsync();

            return Ok(section);
        }

        // ===============================================
        //  Update Section
        // ===============================================
        public class UpdateSectionRequest
        {
            public string? Title { get; set; }
            public int? Order { get; set; }
        }

        [HttpPut("sections/{sectionId}")]
        public async Task<IActionResult> UpdateSection(int sectionId, [FromBody] UpdateSectionRequest request)
        {
            var section = await _context.CourseSections.FindAsync(sectionId);
            if (section == null)
                return NotFound(new { message = "Section not found." });

            if (!string.IsNullOrWhiteSpace(request.Title))
                section.Title = request.Title;

            if (request.Order.HasValue)
                section.Order = request.Order.Value;

            await _context.SaveChangesAsync();

            return Ok(section);
        }

        // ===============================================
        //  Delete Section
        // ===============================================
        [HttpDelete("sections/{sectionId}")]
        public async Task<IActionResult> DeleteSection(int sectionId)
        {
            var section = await _context.CourseSections
                .Include(s => s.ContentItems)
                .FirstOrDefaultAsync(s => s.Id == sectionId);

            if (section == null)
                return NotFound(new { message = "Section not found." });

            _context.CourseContentItems.RemoveRange(section.ContentItems);
            _context.CourseSections.Remove(section);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Section deleted." });
        }

        // ===============================================
        //  Create Content Item
        // ===============================================
        public class CreateContentItemRequest
        {
            public int ContentType { get; set; }
            public string? Title { get; set; }
            public string? Text { get; set; }
            public string? MediaUrl { get; set; }
        }

        [HttpPost("sections/{sectionId}/items")]
        public async Task<IActionResult> CreateContentItem(int sectionId, [FromBody] CreateContentItemRequest request)
        {
            try
            {
                var section = await _context.CourseSections.FindAsync(sectionId);
                if (section == null)
                    return BadRequest(new { message = "Invalid sectionId." });

                if (request.ContentType < 0 || request.ContentType > 3)
                    return BadRequest(new { message = "Invalid content type." });

                var type = (CourseContentType)request.ContentType;

                // Prevent DB NULL errors
                if (type == CourseContentType.Text)
                {
                    if (string.IsNullOrWhiteSpace(request.Text))
                        request.Text = ""; // avoid NULL violation
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(request.MediaUrl))
                        return BadRequest(new { message = "MediaUrl is required for non-text content." });

                    if (string.IsNullOrWhiteSpace(request.Title))
                        request.Title = Path.GetFileName(request.MediaUrl);
                }

                var maxOrder = await _context.CourseContentItems
                    .Where(ci => ci.CourseSectionId == sectionId)
                    .Select(ci => (int?)ci.Order)
                    .MaxAsync() ?? 0;

                var item = new CourseContentItem
                {
                    CourseSectionId = sectionId,
                    ContentType = type,
                    Title = request.Title ?? "",
                    Text = request.Text,     // now allowed to be null safely
                    MediaUrl = request.MediaUrl,
                    Order = maxOrder + 1
                };

                _context.CourseContentItems.Add(item);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    item.Id,
                    item.Title,
                    item.Text,
                    item.MediaUrl,
                    ContentType = item.ContentType.ToString(),
                    item.Order,
                    item.CourseSectionId
                });

            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "Server error while creating content item.",
                    error = ex.Message,
                    inner = ex.InnerException?.Message
                });
            }
        }

        // ===============================================
        //  Update Content Item
        // ===============================================
        public class UpdateContentItemRequest
        {
            public int? ContentType { get; set; }
            public string? Title { get; set; }
            public string? Text { get; set; }
            public string? MediaUrl { get; set; }
            public int? Order { get; set; }
        }

        [HttpPut("items/{itemId}")]
        public async Task<IActionResult> UpdateContentItem(int itemId, [FromBody] UpdateContentItemRequest request)
        {
            var item = await _context.CourseContentItems.FindAsync(itemId);
            if (item == null)
                return NotFound(new { message = "Item not found." });

            if (request.ContentType.HasValue)
                item.ContentType = (CourseContentType)request.ContentType.Value;

            if (request.Title != null)
                item.Title = request.Title;

            item.Text = request.Text;
            item.MediaUrl = request.MediaUrl;

            if (request.Order.HasValue)
                item.Order = request.Order.Value;

            await _context.SaveChangesAsync();

            return Ok(item);
        }

        // ===============================================
        //  Delete Content Item
        // ===============================================
        [HttpDelete("items/{itemId}")]
        public async Task<IActionResult> DeleteContentItem(int itemId)
        {
            var item = await _context.CourseContentItems.FindAsync(itemId);
            if (item == null)
                return NotFound(new { message = "Item not found." });

            _context.CourseContentItems.Remove(item);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Item deleted." });
        }

        // ===============================================
        //  Upload File
        // ===============================================
        [HttpPost("upload-file")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadFile([FromForm] UploadCourseContentFileRequest request)
        {
            var section = await _context.CourseSections.FindAsync(request.SectionId);
            if (section == null)
                return BadRequest(new { message = "Invalid sectionId." });

            if (request.File == null || request.File.Length == 0)
                return BadRequest(new { message = "No file uploaded." });

            var folder = Path.Combine("wwwroot", "uploads", "course-content");
            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            var ext = Path.GetExtension(request.File.FileName);
            var fileName = $"{Guid.NewGuid()}{ext}";
            var path = Path.Combine(folder, fileName);

            using (var fs = new FileStream(path, FileMode.Create))
            {
                await request.File.CopyToAsync(fs);
            }

            var baseUrl = $"{Request.Scheme}://{Request.Host}";
            var url = $"{baseUrl}/uploads/course-content/{fileName}";

            return Ok(new { url });
        }
    }
}
