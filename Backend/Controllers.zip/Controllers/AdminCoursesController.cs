﻿using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.IO;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/admin/courses")]
    [Authorize(Policy = "AdminOnly")]
    public class AdminCoursesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AdminCoursesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/admin/courses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseDto>>> GetAll()
        {
            var result = await _context.Courses
                .Include(c => c.CourseBooks)
                .Include(c => c.LearningPathCourses)
                .Select(c => new CourseDto
                {
                    Id = c.Id,
                    Title = c.Title,
                    Description = c.Description,
                    Price = c.Price,
                    IsActive = c.IsActive,
                    Hours = c.Hours,
                    Category = c.Category,
                    Rating = c.Rating,
                    ThumbnailUrl = c.ThumbnailUrl,
                    BookIds = c.CourseBooks.Select(cb => cb.BookId).ToList(),
                    PathIds = c.LearningPathCourses.Select(lp => lp.LearningPathId).ToList()
                })
                .ToListAsync();

            return Ok(result);
        }

        // GET: api/admin/courses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CourseDto>> GetById(int id)
        {
            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .Include(c => c.LearningPathCourses)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            var dto = new CourseDto
            {
                Id = course.Id,
                Title = course.Title,
                Description = course.Description,
                Price = course.Price,
                IsActive = course.IsActive,
                Hours = course.Hours,
                Category = course.Category,
                Rating = course.Rating,
                ThumbnailUrl = course.ThumbnailUrl,
                BookIds = course.CourseBooks.Select(cb => cb.BookId).ToList(),
                PathIds = course.LearningPathCourses.Select(lp => lp.LearningPathId).ToList()
            };

            return Ok(dto);
        }

        // POST: api/admin/courses
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateCourseRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var course = new Course
                {
                    Title = request.Title,
                    Description = request.Description,
                    Price = request.Price,
                    IsActive = request.IsActive,
                    Hours = request.Hours,
                    Category = request.Category,
                    Rating = request.Rating,
                    ThumbnailUrl = request.ThumbnailUrl
                };

                _context.Courses.Add(course);
                await _context.SaveChangesAsync();

                var bookIds = (request.BookIds ?? new List<int>()).Distinct().ToList();
                if (bookIds.Count > 0)
                {
                    var existingBookIds = await _context.Books
                        .Where(b => bookIds.Contains(b.Id))
                        .Select(b => b.Id)
                        .ToListAsync();

                    foreach (var bookId in existingBookIds)
                    {
                        _context.CourseBooks.Add(new CourseBook
                        {
                            CourseId = course.Id,
                            BookId = bookId
                        });
                    }
                }

                var pathIds = (request.PathIds ?? new List<int>()).Distinct().ToList();
                if (pathIds.Count > 0)
                {
                    var existingPathIds = await _context.LearningPaths
                        .Where(lp => pathIds.Contains(lp.Id))
                        .Select(lp => lp.Id)
                        .ToListAsync();

                    var order = 0;
                    foreach (var pathId in existingPathIds)
                    {
                        _context.LearningPathCourses.Add(new LearningPathCourse
                        {
                            CourseId = course.Id,
                            LearningPathId = pathId,
                            StepOrder = order++
                        });
                    }
                }

                await _context.SaveChangesAsync();

                return Ok(new { message = "Course created successfully.", id = course.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = $"Error while creating course: {ex.Message}",
                    inner = ex.InnerException?.Message
                });
            }
        }

        // PUT: api/admin/courses/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateCourseRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .Include(c => c.LearningPathCourses)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            try
            {
                course.Title = request.Title;
                course.Description = request.Description;
                course.Price = request.Price;
                course.IsActive = request.IsActive;
                course.Hours = request.Hours;
                course.Category = request.Category;
                course.Rating = request.Rating;
                course.ThumbnailUrl = request.ThumbnailUrl;

                var existingCourseBooks = _context.CourseBooks.Where(cb => cb.CourseId == course.Id);
                _context.CourseBooks.RemoveRange(existingCourseBooks);

                var bookIds = (request.BookIds ?? new List<int>()).Distinct().ToList();
                if (bookIds.Count > 0)
                {
                    var existingBookIds = await _context.Books
                        .Where(b => bookIds.Contains(b.Id))
                        .Select(b => b.Id)
                        .ToListAsync();

                    foreach (var bookId in existingBookIds)
                    {
                        _context.CourseBooks.Add(new CourseBook
                        {
                            CourseId = course.Id,
                            BookId = bookId
                        });
                    }
                }

                var existingPathLinks = _context.LearningPathCourses.Where(lp => lp.CourseId == course.Id);
                _context.LearningPathCourses.RemoveRange(existingPathLinks);

                var pathIds = (request.PathIds ?? new List<int>()).Distinct().ToList();
                if (pathIds.Count > 0)
                {
                    var existingPathIds = await _context.LearningPaths
                        .Where(lp => pathIds.Contains(lp.Id))
                        .Select(lp => lp.Id)
                        .ToListAsync();

                    var order = 0;
                    foreach (var pathId in existingPathIds)
                    {
                        _context.LearningPathCourses.Add(new LearningPathCourse
                        {
                            CourseId = course.Id,
                            LearningPathId = pathId,
                            StepOrder = order++
                        });
                    }
                }

                await _context.SaveChangesAsync();

                return Ok(new { message = "Course updated successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = $"Error while updating course: {ex.Message}",
                    inner = ex.InnerException?.Message
                });
            }
        }

        // DELETE: api/admin/courses/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var course = await _context.Courses.FindAsync(id);
            if (course == null)
                return NotFound(new { message = "Course not found." });

            try
            {
                var courseBooks = _context.CourseBooks.Where(cb => cb.CourseId == id);
                _context.CourseBooks.RemoveRange(courseBooks);

                var pathLinks = _context.LearningPathCourses.Where(lp => lp.CourseId == id);
                _context.LearningPathCourses.RemoveRange(pathLinks);

                _context.Courses.Remove(course);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Course deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = $"Error while deleting course: {ex.Message}",
                    inner = ex.InnerException?.Message
                });
            }
        }

        // ==============================
        //  Upload Course Thumbnail
        // ==============================
        [HttpPost("upload-thumbnail")]
        [DisableRequestSizeLimit]
        public async Task<IActionResult> UploadThumbnail(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { message = "No file uploaded." });

            var folder = Path.Combine("wwwroot", "uploads", "course-thumbnails");

            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var path = Path.Combine(folder, fileName);

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var baseUrl = $"{Request.Scheme}://{Request.Host}";
            var url = $"{baseUrl}/uploads/course-thumbnails/{fileName}";

            return Ok(new { url });
        }
    }

    public class CourseDto
    {
        public int Id { get; set; }

        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; }

        public int Hours { get; set; }
        public string Category { get; set; }
        public double Rating { get; set; }

        public string ThumbnailUrl { get; set; }

        public List<int> BookIds { get; set; } = new();
        public List<int> PathIds { get; set; } = new();
    }

    public class CreateCourseRequest
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; } = true;

        public int Hours { get; set; }
        public string Category { get; set; }
        public double Rating { get; set; }

        public string ThumbnailUrl { get; set; }

        public List<int> BookIds { get; set; } = new();
        public List<int> PathIds { get; set; } = new();
    }

    public class UpdateCourseRequest
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; } = true;

        public int Hours { get; set; }
        public string Category { get; set; }
        public double Rating { get; set; }

        public string ThumbnailUrl { get; set; }

        public List<int> BookIds { get; set; } = new();
        public List<int> PathIds { get; set; } = new();
    }
}
