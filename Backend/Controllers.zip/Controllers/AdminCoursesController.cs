﻿using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/admin/courses")]
    [Authorize(Policy = "AdminOnly")]
    public class AdminCoursesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AdminCoursesController(AppDbContext context)
        {
            _context = context;
        }

        // =========================
        //  GET: /api/admin/courses
        //  عرض كل الكورسات (للداشبورد)
        // =========================
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseDto>>> GetAll()
        {
            var courses = await _context.Courses
                .Include(c => c.CourseBooks)
                .ToListAsync();

            var result = courses.Select(c => new CourseDto
            {
                Id = c.Id,
                Title = c.Title,
                Description = c.Description,
                Price = c.Price,
                IsActive = c.IsActive,
                BookIds = c.CourseBooks?.Select(cb => cb.BookId).ToList() ?? new List<int>()
            }).ToList();

            return Ok(result);
        }

        // =========================
        //  GET: /api/admin/courses/{id}
        //  عرض كورس واحد بالتفصيل
        // =========================
        [HttpGet("{id:int}")]
        public async Task<ActionResult<CourseDto>> GetById(int id)
        {
            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            var dto = new CourseDto
            {
                Id = course.Id,
                Title = course.Title,
                Description = course.Description,
                Price = course.Price,
                IsActive = course.IsActive,
                BookIds = course.CourseBooks?.Select(cb => cb.BookId).ToList() ?? new List<int>()
            };

            return Ok(dto);
        }

        // =========================
        //  POST: /api/admin/courses
        //  إنشاء كورس جديد
        // =========================
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateCourseRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Title))
                return BadRequest(new { message = "Title is required." });

            if (request.Price < 0)
                return BadRequest(new { message = "Price cannot be negative." });

            var course = new Course
            {
                Title = request.Title,
                Description = request.Description,
                Price = request.Price,
                IsActive = request.IsActive
            };

            _context.Courses.Add(course);
            await _context.SaveChangesAsync();

            // ربط بالكتب إن وجدت
            if (request.BookIds != null && request.BookIds.Any())
            {
                var validBookIds = await _context.Books
                    .Where(b => request.BookIds.Contains(b.Id))
                    .Select(b => b.Id)
                    .ToListAsync();

                var courseBooks = validBookIds.Select(bookId => new CourseBook
                {
                    CourseId = course.Id,
                    BookId = bookId
                });

                _context.CourseBooks.AddRange(courseBooks);
                await _context.SaveChangesAsync();
            }

            return Ok(new { message = "Course created successfully.", courseId = course.Id });
        }

        // =========================
        //  PUT: /api/admin/courses/{id}
        //  تعديل كورس موجود
        // =========================
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateCourseRequest request)
        {
            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            if (string.IsNullOrWhiteSpace(request.Title))
                return BadRequest(new { message = "Title is required." });

            if (request.Price < 0)
                return BadRequest(new { message = "Price cannot be negative." });

            course.Title = request.Title;
            course.Description = request.Description;
            course.Price = request.Price;
            course.IsActive = request.IsActive;

            // تحديث الربط مع الكتب
            // نحذف القديم
            if (course.CourseBooks != null && course.CourseBooks.Any())
            {
                _context.CourseBooks.RemoveRange(course.CourseBooks);
            }

            // ونضيف الجديد لو فيه
            if (request.BookIds != null && request.BookIds.Any())
            {
                var validBookIds = await _context.Books
                    .Where(b => request.BookIds.Contains(b.Id))
                    .Select(b => b.Id)
                    .ToListAsync();

                var courseBooks = validBookIds.Select(bookId => new CourseBook
                {
                    CourseId = course.Id,
                    BookId = bookId
                });

                _context.CourseBooks.AddRange(courseBooks);
            }

            await _context.SaveChangesAsync();

            return Ok(new { message = "Course updated successfully." });
        }

        // =========================
        //  DELETE: /api/admin/courses/{id}
        //  حذف كورس
        // =========================
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var course = await _context.Courses
                .Include(c => c.CourseBooks)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            if (course.CourseBooks != null && course.CourseBooks.Any())
            {
                _context.CourseBooks.RemoveRange(course.CourseBooks);
            }

            _context.Courses.Remove(course);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Course deleted successfully." });
        }

        // =========================
        //  PATCH: /api/admin/courses/{id}/toggle
        //  تفعيل/تعطيل كورس
        // =========================
        [HttpPatch("{id:int}/toggle")]
        public async Task<IActionResult> ToggleActive(int id)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.Id == id);

            if (course == null)
                return NotFound(new { message = "Course not found." });

            course.IsActive = !course.IsActive;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Course status changed.", isActive = course.IsActive });
        }
    }

    // ==========================
    //   DTOs للكورسات
    // ==========================

    public class CourseDto
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; }
        public List<int> BookIds { get; set; } = new();
    }

    public class CreateCourseRequest
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; } = true;
        public List<int> BookIds { get; set; } = new();
    }

    public class UpdateCourseRequest
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public bool IsActive { get; set; } = true;
        public List<int> BookIds { get; set; } = new();
    }
}
