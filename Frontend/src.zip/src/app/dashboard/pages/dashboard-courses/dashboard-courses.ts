import { Component, OnInit } from '@angular/core';
import { CommonModule, CurrencyPipe, NgIf, NgForOf } from '@angular/common';
import {
  AdminCoursesService,
  AdminCourseDto,
  CreateCourseRequest,
} from '../../../core/services/admin-courses.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  AdminPathsService,
  AdminLearningPathDto,
} from '../../../core/services/admin-paths.service';
import { AdminCourseContentService } from '../../../core/services/admin-course-content.service';
import { CourseContentEditor } from './course-content-editor/course-content-editor';
@Component({
  selector: 'app-dashboard-courses',
  standalone: true,
  imports: [CommonModule, NgIf, NgForOf, CurrencyPipe, ReactiveFormsModule, CourseContentEditor],

  templateUrl: './dashboard-courses.html',
  styleUrl: './dashboard-courses.scss',
})
export class DashboardCourses implements OnInit {
  courses: AdminCourseDto[] = [];
  isLoading = false;
  error: string | null = null;

  // learning paths للـ select
  paths: AdminLearningPathDto[] = [];
  isLoadingPaths = false;

  // فورم الإنشاء / التعديل
  courseForm: FormGroup;
  isSaving = false;

  // 👇 الوضع الجديد: صفحة إيديت كاملة
  isEditorOpen = false; // هل صفحة الإيديت مفتوحة؟
  isCreateMode = false; // true = إنشاء كورس جديد / false = تعديل كورس موجود
  selectedCourse: AdminCourseDto | null = null;

  // 👇 ملخص محتوى الكورس (الأقسام + العناصر)
  contentSummary: any = null;
  contentSummaryLoading = false;
  contentSummaryError: string | null = null;

  constructor(
    private adminCourses: AdminCoursesService,
    private adminPaths: AdminPathsService,
    private adminCourseContent: AdminCourseContentService,
    private fb: FormBuilder
  ) {
    this.courseForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(200)]],
      category: ['', [Validators.required, Validators.maxLength(100)]],
      price: [0, [Validators.required, Validators.min(0)]],
      hours: [0, [Validators.required, Validators.min(0)]],
      thumbnailUrl: ['', [Validators.maxLength(500)]],
      description: ['', [Validators.required, Validators.maxLength(4000)]],
      isActive: [true],
      // إدخال IDs الكتب كنص
      bookIdsText: [''],
      learningPathId: [null], // سنعتبره غير إلزامي هنا، أو تضيف Validators.required لو تحب
    });
  }

  ngOnInit(): void {
    this.loadCourses();
    this.loadPaths();
  }

  // تحميل الكورسات
  loadCourses(): void {
    this.isLoading = true;
    this.error = null;

    this.adminCourses.getAll().subscribe({
      next: (data) => {
        this.courses = data;
        this.isLoading = false;
      },
      error: () => {
        this.error = 'Failed to load courses.';
        this.isLoading = false;
      },
    });
  }

  // تحميل الـ learning paths لاستخدامها في الـ select
  loadPaths(): void {
    this.isLoadingPaths = true;

    this.adminPaths.getAll().subscribe({
      next: (data) => {
        this.paths = data;
        this.isLoadingPaths = false;
      },
      error: () => {
        this.isLoadingPaths = false;
        // نخلي الكورسات تشتغل حتى لو paths فشلت
      },
    });
  }

  // تحويل النص إلى قائمة IDs
  private parseBookIds(text: string): number[] {
    if (!text || !text.trim()) return [];
    return text
      .split(',')
      .map((x) => x.trim())
      .filter((x) => x !== '')
      .map((x) => Number(x))
      .filter((x) => !Number.isNaN(x));
  }

  // ===========================
  //   فتح صفحة الإيديت - إنشاء
  // ===========================
  openCreateEditor(): void {
    this.isEditorOpen = true;
    this.isCreateMode = true;
    this.selectedCourse = null;
    this.error = null;
    this.isSaving = false;

    this.contentSummary = null;
    this.contentSummaryError = null;

    this.courseForm.reset({
      title: '',
      category: '',
      price: 0,
      hours: 0,
      thumbnailUrl: '',
      description: '',
      isActive: true,
      bookIdsText: '',
      learningPathId: this.paths.length > 0 ? this.paths[0].id : null,
    });
  }

  // ===========================
  //   فتح صفحة الإيديت - تعديل
  // ===========================
  openEditEditor(course: AdminCourseDto): void {
    this.isEditorOpen = true;
    this.isCreateMode = false;
    this.selectedCourse = course;
    this.error = null;
    this.isSaving = false;

    // تعبئة الفورم بالقيم الحالية للكورس
    this.courseForm.setValue({
      title: course.title,
      category: course.category || '',
      price: course.price,
      hours: course.hours ?? 0,
      thumbnailUrl: course.thumbnailUrl || '',
      description: course.description,
      isActive: course.isActive,
      bookIdsText: (course.bookIds || []).join(','),
      learningPathId: course.pathIds && course.pathIds.length > 0 ? course.pathIds[0] : null,
    });

    // تحميل ملخص محتوى الكورس (الأقسام + العناصر)
    this.loadContentSummary(course.id);
  }

  // ===========================
  //   إغلاق صفحة الإيديت
  // ===========================
  closeEditor(): void {
    this.isEditorOpen = false;
    this.isCreateMode = false;
    this.selectedCourse = null;
    this.isSaving = false;
    this.error = null;

    this.contentSummary = null;
    this.contentSummaryError = null;
    this.contentSummaryLoading = false;
  }

  // ===========================
  //   إرسال الفورم من صفحة الإيديت
  // ===========================
  onSubmitEditor(): void {
    if (this.courseForm.invalid || this.isSaving) return;

    this.isSaving = true;
    this.error = null;

    const value = this.courseForm.value;

    const payload: CreateCourseRequest = {
      title: value.title,
      description: value.description,
      price: value.price,
      isActive: value.isActive,
      hours: value.hours,
      category: value.category,
      rating: 0, // ممكن تغييره لاحقاً، أو جعله default في الباك إند
      bookIds: this.parseBookIds(value.bookIdsText),
      pathIds: value.learningPathId ? [value.learningPathId] : [],
      thumbnailUrl: value.thumbnailUrl,
    };

    if (this.isCreateMode) {
      // إنشاء كورس جديد
      this.adminCourses.create(payload).subscribe({
        next: () => {
          this.isSaving = false;
          this.closeEditor();
          this.loadCourses();
        },
        error: () => {
          this.isSaving = false;
          this.error = 'Failed to create course.';
        },
      });
    } else if (this.selectedCourse) {
      // تعديل كورس موجود
      this.adminCourses.update(this.selectedCourse.id, payload).subscribe({
        next: () => {
          this.isSaving = false;
          this.closeEditor();
          this.loadCourses();
        },
        error: () => {
          this.isSaving = false;
          this.error = 'Failed to update course.';
        },
      });
    }
  }

  // ===========================
  //   تفعيل / تعطيل
  // ===========================
  onToggle(course: AdminCourseDto): void {
    this.adminCourses.toggleActive(course.id).subscribe({
      next: (res) => {
        course.isActive = res.isActive;
      },
      error: () => {
        this.error = 'Failed to change status.';
      },
    });
  }

  // ===========================
  //   حذف
  // ===========================
  onDelete(course: AdminCourseDto): void {
    const confirmDelete = confirm(`Delete course "${course.title}" ?`);
    if (!confirmDelete) return;

    this.adminCourses.delete(course.id).subscribe({
      next: () => {
        this.courses = this.courses.filter((c) => c.id !== course.id);
      },
      error: () => {
        this.error = 'Failed to delete course.';
      },
    });
  }

  onThumbnailSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      return;
    }

    const file = input.files[0];

    this.adminCourses.uploadThumbnail(file).subscribe({
      next: (res) => {
        this.courseForm.patchValue({ thumbnailUrl: res.url });
      },
      error: () => {
        this.error = 'Failed to upload course image.';
      },
    });

    input.value = '';
  }

  // ===========================
  //   ملخّص محتوى الكورس
  // ===========================
  private loadContentSummary(courseId: number): void {
    this.contentSummaryLoading = true;
    this.contentSummaryError = null;
    this.contentSummary = null;

    this.adminCourseContent.getCourseContent(courseId).subscribe({
      next: (res) => {
        this.contentSummary = res;
        this.contentSummaryLoading = false;
      },
      error: (err) => {
        console.error(err);
        this.contentSummaryError = 'Failed to load course content.';
        this.contentSummaryLoading = false;
      },
    });
  }
}
