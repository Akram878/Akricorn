import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgIf, NgForOf, NgClass, NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  AdminCourseContentService,
  CourseContentResponse,
  CourseSection,
  CourseContentItem,
  CourseContentItemType,
  RawCourseSection,
} from '../../../../core/services/admin-course-content.service';

@Component({
  selector: 'app-course-content-editor',
  standalone: true,
  templateUrl: './course-content-editor.html',
  styleUrl: './course-content-editor.scss',
  imports: [NgIf, NgForOf, NgClass, NgSwitch, NgSwitchCase, NgSwitchDefault, FormsModule],
})
export class CourseContentEditor implements OnChanges {
  @Input() courseId!: number;
  @Input() courseTitle: string | undefined;

  loading = false;
  error: string | null = null;

  content: {
    id: number;
    title: string;
    description: string;
    sections: CourseSection[];
  } | null = null;

  // ====== إنشاء سيكشن ======
  newSectionTitle = '';
  newSectionOrder: number | null = null;

  // ====== إنشاء درس داخل سيكشن ======
  newLessonTitle: { [sectionId: number]: string } = {};
  selectedSectionIdForNewItem: number | null = null;
  newItemType: CourseContentItemType = 'Text';
  newItemText = '';
  newItemMediaUrl = '';

  constructor(private contentService: AdminCourseContentService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['courseId'] && this.courseId) {
      this.loadContent();
    }
  }

  // ==========================
  // تحميل المحتوى من السيرفر
  // ==========================
  loadContent(): void {
    if (!this.courseId) return;

    this.loading = true;
    this.error = null;

    this.contentService.getCourseContent(this.courseId).subscribe({
      next: (res: CourseContentResponse) => {
        this.content = {
          id: res.id,
          title: res.title,
          description: res.description,
          sections: (res.sections || []).map(
            (s: RawCourseSection): CourseSection => ({
              sectionId: s.id,
              title: s.title,
              sectionTitle: s.title,
              sectionOrder: s.order,
              items: (s.items || []).map(
                (i): CourseContentItem => ({
                  id: i.id,
                  title: i.title,
                  order: i.order,
                  text: i.text,
                  mediaUrl: i.mediaUrl,
                  type: this.mapBackendTypeToUiType(i.contentType),
                })
              ),
            })
          ),
        };
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load course content.';
        this.loading = false;
      },
    });
  }

  private mapBackendTypeToUiType(contentType: string): CourseContentItemType {
    switch (contentType) {
      case 'Text':
        return 'Text';
      case 'Video':
        return 'Video';
      case 'File':
        return 'File';
      default:
        return 'Text';
    }
  }

  // ==========================
  // إدارة الأقسام
  // ==========================

  createSection(): void {
    if (!this.newSectionTitle.trim()) return;

    const title = this.newSectionTitle.trim();

    this.contentService.createSection(this.courseId, { title }).subscribe({
      next: () => {
        this.newSectionTitle = '';
        this.newSectionOrder = null;
        this.loadContent();
      },
      error: () => {
        this.error = 'Failed to add section';
      },
    });
  }

  saveSection(section: CourseSection): void {
    const body: { title?: string; order?: number } = {};
    if (section.sectionTitle?.trim()) body.title = section.sectionTitle.trim();
    if (typeof section.sectionOrder === 'number') body.order = section.sectionOrder;

    this.contentService.updateSection(section.sectionId, body).subscribe({
      next: () => this.loadContent(),
      error: () => (this.error = 'Failed to update section'),
    });
  }

  deleteSection(sectionId: number): void {
    if (!confirm('Delete this section?')) return;

    this.contentService.deleteSection(sectionId).subscribe({
      next: () => this.loadContent(),
      error: () => (this.error = 'Failed to delete section'),
    });
  }

  // ==========================
  // إنشاء عنصر جديد (درس)
  // ==========================
  startAddItem(sectionId: number): void {
    this.selectedSectionIdForNewItem = sectionId;
    this.newLessonTitle[sectionId] = '';
    this.newItemType = 'Text';
    this.newItemText = '';
    this.newItemMediaUrl = '';
  }

  cancelAddItem(): void {
    this.selectedSectionIdForNewItem = null;
    this.newItemType = 'Text';
    this.newItemText = '';
    this.newItemMediaUrl = '';
  }

  confirmAddItem(section: CourseSection): void {
    const sectionId = section.sectionId;
    if (!sectionId) return;

    const typeMap: Record<CourseContentItemType, number> = {
      Text: 0,
      Video: 2,
      File: 3,
    };

    const body: {
      contentType: number;
      title?: string;
      text?: string;
      mediaUrl?: string;
    } = {
      contentType: typeMap[this.newItemType],
    };

    const titleInput = this.newLessonTitle[sectionId];
    if (titleInput?.trim()) body.title = titleInput.trim();

    if (this.newItemType === 'Text') {
      if (this.newItemText.trim()) body.text = this.newItemText.trim();
    } else {
      if (this.newItemMediaUrl.trim()) body.mediaUrl = this.newItemMediaUrl.trim();
    }

    this.contentService.createContentItem(sectionId, body).subscribe({
      next: () => {
        this.cancelAddItem();
        this.loadContent();
      },
      error: () => (this.error = 'Failed to create content item'),
    });
  }

  // ==========================
  // تعديل عنصر
  // ==========================
  saveItem(sectionId: number, item: CourseContentItem): void {
    const typeMap: Record<CourseContentItemType, number> = {
      Text: 0,
      Video: 2,
      File: 3,
    };

    const body: any = {};

    if (item.type) body.contentType = typeMap[item.type];
    if (item.title?.trim()) body.title = item.title.trim();
    if (item.type === 'Text') body.text = item.text?.trim() || '';
    else body.mediaUrl = item.mediaUrl?.trim() || '';
    if (typeof item.order === 'number') body.order = item.order;

    this.contentService.updateContentItem(item.id, body).subscribe({
      next: () => this.loadContent(),
      error: () => (this.error = 'Failed to update content item'),
    });
  }

  deleteItem(itemId: number): void {
    if (!confirm('Delete this item?')) return;

    this.contentService.deleteContentItem(itemId).subscribe({
      next: () => this.loadContent(),
      error: () => (this.error = 'Failed to delete item'),
    });
  }

  // ==========================
  // رفع ملفات Drag & Drop
  // ==========================
  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
  }

  onDropFiles(event: DragEvent, sectionId: number): void {
    event.preventDefault();
    const files = event.dataTransfer?.files;
    if (!files?.length) return;

    this.handleFilesUpload(files, sectionId);
  }

  onFilesSelected(event: Event, sectionId: number): void {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;

    this.handleFilesUpload(input.files, sectionId);
    input.value = '';
  }

  private handleFilesUpload(files: FileList, sectionId: number): void {
    Array.from(files).forEach((file) => {
      this.contentService.uploadFile(file, sectionId).subscribe({
        next: (res) => {
          const url = res.url;

          const body = {
            contentType: 3, // File
            title: file.name,
            mediaUrl: url,
          };

          this.contentService.createContentItem(sectionId, body).subscribe({
            next: () => this.loadContent(),
            error: () => (this.error = 'Failed to create file item'),
          });
        },
        error: () => (this.error = 'Failed to upload file'),
      });
    });
  }

  // ==========================
  // Helpers
  // ==========================
  getLessonsForSection(section: CourseSection): CourseContentItem[] {
    return section.items || [];
  }

  getFileDisplayName(url: string): string {
    try {
      return decodeURIComponent(url.split('/').pop() || url);
    } catch {
      return url;
    }
  }
}
