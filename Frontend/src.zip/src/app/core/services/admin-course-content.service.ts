import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdminAuthService } from './admin-auth.service';

export type CourseContentItemType = 'Text' | 'Video' | 'File';

// === RAW MODELS FROM BACKEND ===
export interface RawCourseContentItem {
  id: number;
  contentType: string;
  title?: string;
  text?: string;
  mediaUrl?: string;
  order: number;
}

export interface RawCourseSection {
  id: number;
  title: string;
  order: number;
  items: RawCourseContentItem[];
}

export interface CourseContentResponse {
  id: number;
  title: string;
  description: string;
  sections: RawCourseSection[];
}

// === UI MODELS ===
export interface CourseContentItem {
  id: number;
  type: CourseContentItemType;
  title?: string;
  text?: string;
  mediaUrl?: string;
  order: number;
}

export interface CourseSection {
  sectionId: number;
  title: string;
  sectionTitle?: string;
  sectionOrder: number;
  items: CourseContentItem[];
}

@Injectable({
  providedIn: 'root',
})
export class AdminCourseContentService {
  private baseUrl = 'https://localhost:7150/api/admin/course-content';

  constructor(private http: HttpClient, private adminAuth: AdminAuthService) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.adminAuth.getToken();
    let headers = new HttpHeaders();
    if (token) headers = headers.set('Authorization', `Bearer ${token}`);
    return headers;
  }

  // ===========================
  // GET COURSE CONTENT
  // ===========================
  getCourseContent(courseId: number): Observable<CourseContentResponse> {
    return this.http.get<CourseContentResponse>(`${this.baseUrl}/course/${courseId}`, {
      headers: this.getAuthHeaders(),
    });
  }

  // ===========================
  // SECTION CRUD
  // ===========================
  createSection(courseId: number, body: { title: string }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/course/${courseId}/sections`, body, {
      headers: this.getAuthHeaders(),
    });
  }

  updateSection(sectionId: number, body: { title?: string; order?: number }): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/sections/${sectionId}`, body, {
      headers: this.getAuthHeaders(),
    });
  }

  deleteSection(sectionId: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/sections/${sectionId}`, {
      headers: this.getAuthHeaders(),
    });
  }

  // ===========================
  // CONTENT ITEM CRUD
  // ===========================
  createContentItem(
    sectionId: number,
    body: { contentType: number; title?: string; text?: string; mediaUrl?: string; order?: number }
  ): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/sections/${sectionId}/items`, body, {
      headers: this.getAuthHeaders(),
    });
  }

  updateContentItem(
    itemId: number,
    body: { contentType?: number; title?: string; text?: string; mediaUrl?: string; order?: number }
  ): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/items/${itemId}`, body, {
      headers: this.getAuthHeaders(),
    });
  }

  deleteContentItem(itemId: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/items/${itemId}`, {
      headers: this.getAuthHeaders(),
    });
  }

  // ===========================
  // FIXED 100% FILE UPLOAD
  // now includes SectionId
  // ===========================
  uploadFile(file: File, sectionId: number): Observable<{ url: string }> {
    const formData = new FormData();

    // FIX: backend expects “SectionId”
    formData.append('SectionId', sectionId.toString());
    formData.append('File', file); // MUST match IFormFile File

    return this.http.post<{ url: string }>(`${this.baseUrl}/upload-file`, formData, {
      headers: this.getAuthHeaders(),
    });
  }
}
