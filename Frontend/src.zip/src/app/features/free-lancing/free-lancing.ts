import { Component } from '@angular/core';

@Component({
  selector: 'app-free-lancing',
  imports: [],
  templateUrl: './free-lancing.html',
  styleUrl: './free-lancing.scss'
})
export class FreeLancing {

}
