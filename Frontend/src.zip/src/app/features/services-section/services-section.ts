import { Component } from '@angular/core';

@Component({
  selector: 'app-services-section',
  imports: [],
  templateUrl: './services-section.html',
  styleUrl: './services-section.scss'
})
export class ServicesSection {

}
